p0Trial of Notch：创世神审判》Mod v1.0.0

By benyexi — 一个造梦世界的神之玩家。

⸻

简介（中文）

《Trial of Notch：创世神审判》是一款高自由度、Boss主导型的Minecraft神级模组，融合剧情、RPG元素、技能特效、维度探索与神器构建于一体。

你将在这里面对创世神Notch本尊，以及他的三大审判者：凋零泰坦、凋零斯拉、执行之龙。击败他们，你将获得控制世界的力量。

⸻

特性：
	•	5大超神Boss：每个拥有独立模型、出场演出、狂暴阶段与掉落系统
	•	神器系统：
	•	终极斩神剑（绑定、不可掉落）
	•	炼狱之剑（火焰太极技能）
	•	毁灭之剑（Warden音波+地面震动）
	•	炼狱维度：通过远古残骸传送门进入，神战爆发之地
	•	仓库系统：背包溢出自动存入，右下角UI点击提取
	•	称号系统：击败Notch后获得炫彩“创世者”称号（聊天与头顶动态显示）
	•	Patchouli三本手册：
	•	Boss介绍
	•	维度传送门图示 + 世界机制
	•	所有武器装备收集方法与技能描述
	•	技能演出：
	•	炼狱斩：红蓝旋转火焰太极
	•	毁灭一切：四周释放Warden音波并震动地面10秒

⸻

安装说明：
	1.	Minecraft版本：1.20.1
	2.	Forge版本：推荐使用 Forge 47.2.x
	3.	所需依赖：
	•	KubeJS 1901.6.3+
	•	Patchouli 1.20.1-81+
	4.	将整合包 TrialOfNotch-v1.0.0.zip 导入到 HMCL、CurseForge 启动器
	5.	启动后获得三本手册并解锁开场成就：“创世神の降临”

⸻

英文介绍（English）

Trial of Notch: The Divine Judgment Begins.

This mod lets you battle colossal god-tier bosses like the 600-block Execution Dragon and the Creator himself—Notch.
It includes custom skills, dimensions, weapons, particle animations, and a fully dynamic trial system.
