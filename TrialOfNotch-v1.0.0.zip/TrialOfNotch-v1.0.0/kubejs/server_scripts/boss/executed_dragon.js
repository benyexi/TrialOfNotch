// executed_dragon.js - 执行之龙 Boss 行为逻辑

EntityEvents.spawned(event => {
  const entity = event.entity
  if (entity.type != 'yourmod:executed_dragon') return

  entity.setPersistenceRequired()

  // 出场演出
  event.server.runCommand(`particle minecraft:end_rod ${entity.x} ${entity.y + 50} ${entity.z} 10 100 10 0.5 500 force`)
  event.server.runCommand(`playsound minecraft:entity.ender_dragon.growl master @a ${entity.x} ${entity.y} ${entity.z} 10 1`)
  event.server.runCommand(`title @a title {"text":"§5审判之龙 腾空而起！","bold":true}`)

  // 初始化狂暴阶段标记
  entity.persistentData.putBoolean('normal_rage', false)
  entity.persistentData.putBoolean('extreme_rage', false)
})

EntityEvents.tick(event => {
  const entity = event.entity
  if (entity.type != 'yourmod:executed_dragon') return
  if (entity.dead) return

  const hpRatio = entity.health / entity.maxHealth

  // 普通狂暴阶段：血量50%-33%期间
  if (hpRatio <= 0.5 && hpRatio > 0.33 && !entity.persistentData.getBoolean('normal_rage')) {
    entity.persistentData.putBoolean('normal_rage', true)
    entity.getAttribute('minecraft:generic.attack_damage').baseValue *= 1.2
    entity.getAttribute('minecraft:generic.armor').baseValue *= 1.6
    event.server.runCommand(`title @a title {"text":"§c执行之龙进入普通狂暴！防御提升！破甲率提升！"}`)
  }

  // 极度狂暴阶段：血量低于33%
  if (hpRatio <= 0.33 && !entity.persistentData.getBoolean('extreme_rage')) {
    entity.persistentData.putBoolean('extreme_rage', true)
    entity.getAttribute('minecraft:generic.attack_damage').baseValue *= 2.0
    entity.getAttribute('minecraft:generic.armor').baseValue *= 2.0
    event.server.runCommand(`title @a title {"text":"§4执行之龙进入极度狂暴！每5秒攻击一次！防御翻倍！"}`)
  }
})