// wither_titan.js - 凋零泰坦 Boss 行为逻辑

EntityEvents.spawned(event => {
  const entity = event.entity
  if (entity.type != 'yourmod:wither_titan') return

  entity.setPersistenceRequired()

  // 出场演出
  event.server.runCommand(`particle minecraft:cloud ${entity.x} ${entity.y + 1} ${entity.z} 0 2 0 0.2 100 force`)
  event.server.runCommand(`playsound minecraft:entity.wither.spawn master @a ${entity.x} ${entity.y} ${entity.z} 10 1`)
  event.server.runCommand(`title @a title {"text":"§7凋零泰坦复苏！","bold":true}`)

  // 记录击败数量
  entity.server.schedule(1, () => {
    entity.persistentData.putInt('wither_titan_killed', 0)
  })
})

EntityEvents.death(event => {
  const entity = event.entity
  const killer = event.source.actualPlayer
  if (entity.type != 'yourmod:wither_titan' || !killer) return

  let kills = killer.persistentData.getInt('wither_titan_killed') || 0
  killer.persistentData.putInt('wither_titan_killed', kills + 1)
  killer.tell(`§a你已击败 ${kills + 1} 只凋零泰坦！`)

  // 记录击败100只可以触发凋零斯拉生成（由另一脚本控制）
})