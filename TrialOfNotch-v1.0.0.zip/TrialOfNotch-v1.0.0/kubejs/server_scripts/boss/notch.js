// notch.js - Notch (创世神) Boss 行为逻辑

EntityEvents.spawned(event => {
  const entity = event.entity
  if (entity.type != 'yourmod:notch') return

  entity.setPersistenceRequired()

  // 出场演出
  event.server.runCommand(`particle minecraft:explosion_emitter ${entity.x} ${entity.y + 1} ${entity.z} 0 0 0 0.1 1 force`)
  event.server.runCommand(`playsound minecraft:entity.wither.spawn master @a ${entity.x} ${entity.y} ${entity.z} 10 1`)
  event.server.runCommand(`title @a title {"text":"§6创世神 Notch 降临！","bold":true}`)

  // 记录初始状态
  entity.persistentData.putInt('attack_cd', 40) // 初始2秒攻击一次
  entity.persistentData.putBoolean('rage', false)
})

EntityEvents.tick(event => {
  const entity = event.entity
  if (entity.type != 'yourmod:notch') return
  if (entity.dead) return

  const hpRatio = entity.health / entity.maxHealth

  // 狂暴阶段：血量低于33%变成每0.5秒攻击一次
  if (hpRatio <= 0.33 && !entity.persistentData.getBoolean('rage')) {
    entity.persistentData.putBoolean('rage', true)
    entity.persistentData.putInt('attack_cd', 10)
    event.server.runCommand(`title @a title {"text":"§cNotch进入狂暴状态！准备承受神罚！"}`)
  }

  // 攻击逻辑（略化，可自行绑定技能/AI攻击）
})