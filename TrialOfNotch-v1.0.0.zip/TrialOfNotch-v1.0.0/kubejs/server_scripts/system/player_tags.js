// player_tags.js - 玩家动态称号系统

ServerEvents.tick(event => {
  const server = event.server
  server.players.forEach(player => {
    if (player.persistentData.getBoolean('is_creator')) {
      const tick = server.runTime % 7
      const colors = ["red", "gold", "yellow", "green", "aqua", "blue", "light_purple"]
      const color = colors[tick]
      player.runCommandSilent(`team modify creator prefix {"text":"[创世者] ","bold":true,"color":"${color}"}`)
    }
  })
})

// 玩家击败Notch时触发
EntityEvents.death(event => {
  const entity = event.entity
  const killer = event.source.actualPlayer
  if (entity.type != 'yourmod:notch' || !killer) return

  // 设置炫彩称号
  killer.persistentData.putBoolean('is_creator', true)
  killer.runCommand(`team add creator`)
  killer.runCommand(`team modify creator color reset`)
  killer.runCommand(`team modify creator prefix {"text":"[创世者] ","bold":true,"color":"aqua"}`)
  killer.runCommand(`team join creator ${killer.username}`)
})