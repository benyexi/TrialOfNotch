// doom_burst.js - 毁灭一切技能逻辑（带真实伤害）

PlayerEvents.rightClick(event => {
  const player = event.player
  const item = player.mainHandItem

  // 只允许使用毁灭之剑释放技能
  if (!item || item.id != 'yourmod:doom_blade') return

  const cooldown = player.persistentData.getInt('doom_burst_cooldown') || 0
  if (cooldown > 0) {
    player.tell(`§7技能冷却中，还需 ${cooldown / 20} 秒`)
    return
  }

  const centerX = player.x
  const centerY = player.y + 1
  const centerZ = player.z

  // 发射Warden音波粒子
  for (let angle = 0; angle < 360; angle += 15) {
    const rad = angle * Math.PI / 180
    const x = Math.cos(rad) * 10
    const z = Math.sin(rad) * 10
    player.level.runCommand(`particle minecraft:sonic_boom ${centerX + x} ${centerY} ${centerZ + z} 0 0 0 0.2 10 force`)
  }

  // 地面震动模拟
  for (let i = 0; i < 200; i += 10) {
    player.server.schedule(i, () => {
      player.level.runCommand(`particle minecraft:block minecraft:stone ${centerX} ${centerY - 1} ${centerZ} 4 1 4 0.2 50 force`)
      player.level.runCommand(`playsound minecraft:block.stone.break master @a ${centerX} ${centerY} ${centerZ} 10 1`)
    })
  }

  // 真实造成伤害：半径100格内所有敌对生物
  const entities = player.level.getEntitiesWithin(AABB.of(
    player.x - 100, player.y - 10, player.z - 100,
    player.x + 100, player.y + 10, player.z + 100
  ))

  entities.forEach(ent => {
    if (ent.isLiving() && !ent.isPlayer()) {
      ent.attack(1000000000000) // 1兆点伤害，直接秒杀
    }
  })

  player.runCommand(`playsound minecraft:entity.warden.sonic_boom master @s ~ ~ ~ 5`)
  player.tell('§4释放技能：毁灭一切！（范围真实秒杀）')

  // 设置90秒冷却
  player.persistentData.putInt('doom_burst_cooldown', 1800)
})

ServerEvents.tick(event => {
  event.server.players.forEach(player => {
    if (player.persistentData.getInt('doom_burst_cooldown') > 0) {
      player.persistentData.putInt('doom_burst_cooldown', player.persistentData.getInt('doom_burst_cooldown') - 1)
    }
  })
})