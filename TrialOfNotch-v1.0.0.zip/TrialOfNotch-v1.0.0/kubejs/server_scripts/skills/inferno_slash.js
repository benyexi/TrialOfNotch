// inferno_slash.js - 炼狱太极斩技能逻辑

PlayerEvents.rightClick(event => {
  const player = event.player
  const item = player.mainHandItem

  // 只允许使用炼狱之剑释放技能
  if (!item || item.id != 'yourmod:hell_blade') return

  const cooldown = player.persistentData.getInt('inferno_slash_cooldown') || 0
  if (cooldown > 0) {
    player.tell(`§7技能冷却中，还需 ${cooldown / 20} 秒`)
    return
  }

  const centerX = player.x
  const centerY = player.y + 1
  const centerZ = player.z

  for (let i = 0; i < 360; i += 8) {
    const rad = i * Math.PI / 180
    const xR = Math.cos(rad) * 2
    const zR = Math.sin(rad) * 2
    const xB = Math.cos(-rad) * 2
    const zB = Math.sin(-rad) * 2

    // 红色火焰圈
    player.level.runCommand(`particle minecraft:flame ${centerX + xR} ${centerY} ${centerZ + zR} 0 0 0 0 1 force`)
    // 蓝色灵魂火焰圈
    player.level.runCommand(`particle minecraft:soul_fire_flame ${centerX + xB} ${centerY} ${centerZ + zB} 0 0 0 0 1 force`)
  }

  player.runCommand(`playsound minecraft:item.firecharge.use master @s ~ ~ ~ 2`)
  player.tell('§c释放技能：炼狱太极斩！')

  // 设置60秒冷却
  player.persistentData.putInt('inferno_slash_cooldown', 1200)
})

ServerEvents.tick(event => {
  event.server.players.forEach(player => {
    if (player.persistentData.getInt('inferno_slash_cooldown') > 0) {
      player.persistentData.putInt('inferno_slash_cooldown', player.persistentData.getInt('inferno_slash_cooldown') - 1)
    }
  })
})