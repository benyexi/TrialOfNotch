// drop_system.js - Boss击败后掉落系统（符合最新设定）

EntityEvents.death(event => {
  const entity = event.entity
  const killer = event.source.actualPlayer
  if (!killer) return

  // 击败凋零泰坦
  if (entity.type == 'yourmod:wither_titan') {
    if (Math.random() < 0.0287) {
      const items = ['yourmod:immortal_helmet', 'yourmod:immortal_chestplate', 'yourmod:immortal_leggings', 'yourmod:immortal_boots']
      const randomItem = items[Math.floor(Math.random() * items.length)]
      giveOrStore(killer, Item.of(randomItem))
      killer.tell('§6获得不死套装部件！')
    }
    if (Math.random() < 0.0043) {
      giveOrStore(killer, Item.of('yourmod:doom_blade'))
      killer.tell('§4获得毁灭之剑！')
    }
  }

  // 击败凋零斯拉
  if (entity.type == 'yourmod:wither_sla') {
    // 给所有方块
    const allBlocks = Item.getRegistry().filter(item => item.id.startsWith('minecraft:') && item.id.includes('block'))
    allBlocks.forEach(block => {
      giveOrStore(killer, Item.of(block))
    })

    // 给无限套装
    const infiniteSet = [
      'yourmod:infinite_helmet',
      'yourmod:infinite_chestplate',
      'yourmod:infinite_leggings',
      'yourmod:infinite_boots'
    ]
    infiniteSet.forEach(item => {
      giveOrStore(killer, Item.of(item))
    })

    killer.tell('§b获得所有方块与无限套装！')
  }

  // 击败执行之龙
  if (entity.type == 'yourmod:executed_dragon') {
    // 给所有方块
    const allBlocks = Item.getRegistry().filter(item => item.id.startsWith('minecraft:') && item.id.includes('block'))
    allBlocks.forEach(block => {
      giveOrStore(killer, Item.of(block))
    })

    // 给武器（排除毁灭之剑）
    const weapons = [
      'yourmod:hell_blade', // 炼狱之剑
      // 如果还有其他武器，比如 trial_blade，可以一并列入
    ]
    weapons.forEach(wpn => {
      giveOrStore(killer, Item.of(wpn))
    })

    killer.tell('§d获得所有方块与炼狱之剑！')
  }
})