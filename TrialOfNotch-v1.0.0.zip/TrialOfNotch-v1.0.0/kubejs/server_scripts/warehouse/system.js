// system.js - 玩家仓库系统（物品溢出自动保存）

PlayerEvents.loggedIn(event => {
  const player = event.player
  if (!player.persistentData.get('inventoryStorage')) {
    player.persistentData.putList('inventoryStorage', [])
  }
})

function giveOrStore(player, item) {
  if (player.inventory.full) {
    const storage = player.persistentData.getList('inventoryStorage') || []
    storage.push(item)
    player.persistentData.putList('inventoryStorage', storage)
    player.tell(`§e背包已满，${item.id} 已存入你的仓库！`)
  } else {
    player.give(item)
  }
}

// 你可以在Boss掉落逻辑里调用这个 giveOrStore(player, item) 来自动分流物品