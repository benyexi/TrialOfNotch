// warehouse_ui.js - 仓库界面UI按钮（右下角背包界面按钮）

ClientEvents.lang('zh_cn', e => {
  e.add('screen.kubejs.open_warehouse', '§e打开仓库')
})

ClientEvents.highPriorityAssets(e => {
  e.addJson('kubejs:client_scripts/warehouse_button.json', {
    "type": "button",
    "position": {
      "x": -26,  // 背包界面右下角偏移
      "y": -12
    },
    "size": {
      "width": 20,
      "height": 20
    },
    "texture": "minecraft:item/ender_chest",
    "tooltip": "screen.kubejs.open_warehouse",
    "on_click": "kubejs:open_warehouse_screen"
  })
})

ClientEvents.register("kubejs:open_warehouse_screen", event => {
  const ui = event.createGui("玩家仓库", 176, 166)
  const storage = event.player.persistentData.getList('inventoryStorage') || []

  let y = 20
  storage.forEach(itemStr => {
    ui.label(`${itemStr}`).position(10, y)
    y += 10
  })

  ui.show()
})